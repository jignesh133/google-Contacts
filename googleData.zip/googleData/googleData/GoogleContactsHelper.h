//
//  GoogleContactsHelper.h
//  googleData
//
//  Created by OWNER on 02/08/17.
//  Copyright © 2017 OWNER. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AppAuth.h>
#import "AppDelegate.h"
// CREATED THE GOOLE CONTACT BLOCK

typedef void (^GoogleContactBlock)(id  _Nullable result, NSString  * _Nullable error);

@class OIDAuthState;
@class OIDServiceConfiguration;

@interface GoogleContactsHelper : NSObject{
    GoogleContactBlock googleContactBlock;
}

+ (id _Nullable )Instance;
-(void)getGoogleContact:(GoogleContactBlock _Nullable)block;

@property(nonatomic, strong, nullable) OIDAuthState *authState;

@end
