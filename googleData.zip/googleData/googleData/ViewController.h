//
//  ViewController.h
//  googleData
//
//  Created by OWNER on 02/08/17.
//  Copyright © 2017 OWNER. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AppAuth.h>
#import "AppDelegate.h"


@class OIDAuthState;
@class OIDServiceConfiguration;

@interface ViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{


    IBOutlet UITableView *tableview;
    AppDelegate *appdelegate;
}

-(IBAction)buttonGoogleClick:(id)sender;

@property(nonatomic, strong, nullable) OIDAuthState *authState;

@end

