//
//  ViewController.m
//  googleData
//
//  Created by OWNER on 02/08/17.
//  Copyright © 2017 OWNER. All rights reserved.
//

#import "ViewController.h"
#import <AppAuth.h>
#import "GoogleContactsHelper.h"

@interface ViewController (){
    NSMutableArray *arrData;
}
@end

@implementation ViewController
static NSString *const kIssuer = @"https://accounts.google.com";
-(void)buttonGoogleClick:(id)sender{
    [[GoogleContactsHelper Instance] getGoogleContact:^(id result, NSString *error) {
        if (result) {
            arrData = [[NSMutableArray alloc] initWithArray:[result valueForKeyPath:@"feed.entry"]];
            dispatch_async(dispatch_get_main_queue(), ^{
                [tableview reloadData];
            });
            NSLog(@"%@",result);
        }
        else{
            NSLog(@"%@",error);
        }
    }];
}
//********************************************************************************************************************
//********************************************************* view Did Load *********************************************
-(void)viewDidLoad{
    [super viewDidLoad];
}
//********************************************************************************************************************
#pragma mark -
#pragma mark - UITableview
//********************************************************* UITableview Delega ****************************************

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [arrData count];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 66.0f;
}
-(UITableViewCell *)tableView:(UITableView *)tableView  cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString *CellIdentifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
  
    if ([[[arrData objectAtIndex:indexPath.row] allKeys] containsObject:@"gd$name"]){
        cell.textLabel.text = [[arrData objectAtIndex:indexPath.row] valueForKeyPath:@"gd$name.gd$fullName.$t"];
    }
    else if ([[[arrData objectAtIndex:indexPath.row] allKeys] containsObject:@"title"]) {
    cell.textLabel.text = [[arrData objectAtIndex:0]valueForKeyPath:@"title.$t"];
    }else{
    cell.textLabel.text = @"No Title";
    }

    if ([[[arrData objectAtIndex:indexPath.row] allKeys] containsObject:@"gd$email"]){
        cell.detailTextLabel.text = [[[[arrData objectAtIndex:indexPath.row] valueForKey:@"gd$email"] valueForKey:@"address"] objectAtIndex:0];
    }
    else{
        cell.detailTextLabel.text =@"No Details Found";
    }
    
    return cell;
}

@end
