//
//  AppDelegate.h
//  googleData
//
//  Created by OWNER on 02/08/17.
//  Copyright © 2017 OWNER. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import <AppAuth.h>
#import "WebViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>{

}

@property (strong, nonatomic) UIWindow * window;

@property (readonly, strong) NSPersistentContainer *persistentContainer;

@property(nonatomic, strong, nullable)id<OIDAuthorizationFlowSession> currentAuthorizationFlow;
@property(nonatomic, strong, nullable)NSString *strCode;

- (void)saveContext;
+ (AppDelegate  *)sharedAppDelegate;


@end

