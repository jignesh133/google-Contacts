//
//  GoogleContactsHelper.m
//  googleData
//
//  Created by OWNER on 02/08/17.
//  Copyright © 2017 OWNER. All rights reserved.
//

#import "GoogleContactsHelper.h"

#define kClientId @"94123168008-s3qc5f75h46kuchftgehlij4fbudsl50.apps.googleusercontent.com"
#define KRedirectURL @"com.googleusercontent.apps.94123168008-s3qc5f75h46kuchftgehlij4fbudsl50:/oauthredirect"


@implementation GoogleContactsHelper
+ (id)Instance{
    static id sharedManager;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        sharedManager = [[self alloc] init];
    });
    return sharedManager;
}
-(void)getGoogleContact:(GoogleContactBlock)block{
    // INITILIZE THE BLOCK
    googleContactBlock = block;
    
    NSURL *authorizationEndpoint =
    [NSURL URLWithString:@"https://accounts.google.com/o/oauth2/v2/auth"];
    NSURL *tokenEndpoint =
    [NSURL URLWithString:@"https://www.googleapis.com/oauth2/v4/token"];
    
    OIDServiceConfiguration *configuration =
    [[OIDServiceConfiguration alloc]
     initWithAuthorizationEndpoint:authorizationEndpoint
     tokenEndpoint:tokenEndpoint];
    
    // MAKING THE REQUEST
    OIDAuthorizationRequest *request =
    [[OIDAuthorizationRequest alloc] initWithConfiguration:configuration
                                                  clientId:kClientId
                                                    scopes:@[OIDScopeOpenID,
                                                             OIDScopeProfile,@"https://www.googleapis.com/auth/contacts.readonly"]
                                               redirectURL:[NSURL URLWithString:KRedirectURL]
                                              responseType:OIDResponseTypeCode
                                      additionalParameters:nil];
    
    // performs authentication request
    AppDelegate *appDelegate =
    (AppDelegate *)[UIApplication sharedApplication].delegate;
    appDelegate.currentAuthorizationFlow =
    [OIDAuthState authStateByPresentingAuthorizationRequest:request
                                   presentingViewController:[self topMostController]
                                                   callback:^(OIDAuthState *_Nullable authState,
                                                              NSError *_Nullable error) {
                                                      
                                                       if (authState) {
                                                           NSLog(@"Got authorization tokens. Access token: %@",
                                                                 authState.lastTokenResponse.accessToken);
                                                           NSString *strToken = authState.lastTokenResponse.accessToken;
                                                           [self setAuthState:authState];
                                                           
                                                               //CREATING THE URL
                                                               NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"https://www.google.com/m8/feeds/contacts/default/full?alt=json&v=3.0&oauth_token=%@",strToken]];

                                                                //CREATING THE SESSION
                                                               NSURLSession *session = [NSURLSession sharedSession];
                                                               NSURLSessionDataTask *data = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                                                                   NSError *erro = nil;
                                                                   if (data!=nil) {
                                                                       NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&erro ];
                                                                   // RETURN THE RESULE
                                                                   if (googleContactBlock) {
                                                                        googleContactBlock(json,@"");
                                                                   }
                                                                }
                                                               }];
                                                               [data resume];
                                                        }
                                                       else
                                                       {
                                                           if (googleContactBlock) {
                                                               googleContactBlock(@"",[error localizedDescription]);
                                                           }
                                                           NSLog(@"Authorization error: %@", [error localizedDescription]);
                                                           [self setAuthState:nil];
                                                       }
                                                   }];
}

- (UIViewController*) topMostController
{
    UIViewController *topController = [UIApplication sharedApplication].keyWindow.rootViewController;
    
    while (topController.presentedViewController) {
        topController = topController.presentedViewController;
    }
    
    return topController;
}
@end
